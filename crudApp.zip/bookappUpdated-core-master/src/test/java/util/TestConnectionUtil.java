package util;
import util.ConnectionUtil;
public class TestConnectionUtil {
	public static void main(String[] args) {
		System.out.println(ConnectionUtil.getJdbcTemplate());
	}

}
